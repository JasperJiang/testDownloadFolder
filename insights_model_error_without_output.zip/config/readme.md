# Config Directory

This folder should contain any script/model settings files that are required e.g. yaml config files  