# Insights Model Deployment Template
Template folder structure for deploying models on the insights platform
