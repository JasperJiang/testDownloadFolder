import pandas as pd
from sklearn.externals import joblib
import argparse
import base64
import json

# -------------------------------------------------------------------------- #
#            GLOBAL VARIABLES --- CHANGE BASED ON YOUR SPECIFIC MODEL
# -------------------------------------------------------------------------- #
MODEL_NAME = "YOUR_MODEL_NAME"
MODEL_VERSION = "v1.0.0"
ERROR_MESSAGE = ""
JSON_OUTPUT_NAME = MODEL_NAME+"_Results.json"

# Variables that need to be changed based on expected number of output files
OUTPUT_TYPES = ['single_output', 'multi_output']
NUM_OUTPUT_FILES = OUTPUT_TYPES[0]

# -------------------------------------------------------------------------- #
#           Load Models --- CHANGE BASED ON YOUR SPECIFIC MODEL
# -------------------------------------------------------------------------- #
'''
try:
    load model commands here
    E.g. clf_bsis = joblib.load('bs_is_predict.pkl')
except:
    ERROR_MESSAGE += "** Failed loading model."
'''

# -------------------------------------------------------------------------------------------------------------------- #
#           Insights Specific parameters --- DEFAULT - DO NOT REMOVE
# -------------------------------------------------------------------------------------------------------------------- #
# parsing parameters from API
parser = argparse.ArgumentParser()
parser.add_argument('--InputFile')
parser.add_argument('--OutputFile')
# parser.add_argument('--Temp')

strings = parser.parse_args()

outfile = strings.OutputFile
infile = strings.InputFile

# # Directories to test from local machine || Comment out prior to deploying
# infile = '../input/input.json'

# outfile = '../output/'+JSON_OUTPUT_NAME

# -------------------------------------------------------------------------------------------------------------------- #
#           Load json Function  --- DEFAULT - DO NOT REMOVE
# -------------------------------------------------------------------------------------------------------------------- #
try:
    with open(infile) as data_file:
        input_json = json.load(data_file)
except:
    ERROR_MESSAGE += "** Unable to load input json file, make sure the file is in the correct format and try again."

# -------------------------------------------------------------------------- #
#           Set GLOBAL variables --- CHANGE BASED ON YOUR SPECIFIC MODEL
# DATA object might need changing if your model expects more than 1 input
# -------------------------------------------------------------------------- #
try:
    # extract objects from the input file
    PARAMETERS = input_json['parameters']
    DATA = input_json['data'][0]['content']
except:
    ERROR_MESSAGE += "** One or more expected objects were not included in the json."

# -------------------------------------------------------------------------- #
#           Set default GLOBAL variables for optimized consumption
# -------------------------------------------------------------------------- #
try:
    FILENAME = input_json['data'][0]['filename'] # Value should be present if coming from ai services layer.
except:
    FILENAME = ''  # DEFAULT VALUE

try:
    FORMAT = input_json['data'][0]['format'] # Value should be present if coming from ai services layer.
except:
    FORMAT = 'dataframe' # DEFAULT VALUE

try:
    TRANSFORM = input_json['data'][0]['transform'] # Value should be present if coming from ai services layer.
except:
    TRANSFORM = 'no' # DEFAULT VALUE
# -------------------------------------------------------------------------- #
#           Determining which built in json read function needs to be used
# -------------------------------------------------------------------------- #
try:
    if FORMAT == "dataframe":

        # optimized input
        if TRANSFORM == "no":
            # Initiate specific column types here via dtype
            df = pd.read_json(json.dumps(DATA), orient='records', dtype={"GL Account Number": object, "GL Account Number Descriptions": object})

        # schema based input to deal with excel conversions from DL
        elif TRANSFORM == "yes":
            # Initiate specific column types here via dtype
            df = pd.read_json(json.dumps(DATA), orient='table', dtype={"GL Account Number": object, "GL Account Number Descriptions": object})

    else:
        '''
        ** If your model only accepts dataframes, then you should include an additional error message here.
        ** If your model expects objects in addition to or other than dataframes, you need to modify this function and various error messages
        '''
        ERROR_MESSAGE += "** Model expected tabular data, make sure the data has a tabular structure."


except:
    ERROR_MESSAGE += "** json object not in an acceptable format."


# -------------------------------------------------------------------------- #
#            Data Processing Function--- CHANGE BASED ON YOUR SPECIFIC MODEL
# -------------------------------------------------------------------------- #
'''
Custom functions to handle any data pre processing / feature transformation that is required prior to running inferences

try:
    perform transformations
except:
    ERROR_MESSAGE += "** Data transformations failed."

'''

# -------------------------------------------------------------------------- #
#          Running prediction functions
# -------------------------------------------------------------------------- #
'''
try:
    Predict inferences
    E.g. prediction_bsis = clf_bsis.predict(X = dataset.values)
except:
    ERROR_MESSAGE += "** Error with performing inference."    
'''


# -------------------------------------------------------------------------- #
#           Creating output files
# -------------------------------------------------------------------------- #
'''
try:
    df = pd.DataFrame(   
        {'GL_ACCOUNT': gl_acc,
         'GL_ACCOUNT_DESC': gl_acc_desc,
         'FS': prediction_bsis,
         'FSLI': prediction_fsli
        })
except:
    ERROR_MESSAGE += "** Error with creating output dataframe."
'''

# -------------------------------------------------------------------------- #
#           Output data to send back to AI services layer
# -------------------------------------------------------------------------- #

try:

    OUTPUT_DATA = json.loads(df.to_json(orient='table')) if TRANSFORM == "yes" else json.loads(df.to_json(orient='records'))

    # JSON file that will be returned to the AI services layer
    output_structure = {
        "model_version" : MODEL_VERSION,
        "runtime_error" : ERROR_MESSAGE,
        "output_type" : NUM_OUTPUT_FILES,
        "output_filename" : JSON_OUTPUT_NAME,
        "parameters" : PARAMETERS,
        "data" : [{
              "format" : FORMAT,
              "transform" : TRANSFORM,
              "content" :OUTPUT_DATA
          }
        ]
    }

    # output json file
    with open(outfile, 'w') as output_file:
        json.dump(output_structure, output_file, indent=3)
except:
    ERROR_MESSAGE += "** Error in creating json output file."

# -------------------------------------------------------------------------- #
#           API Error Functions
# If the api fails, error messages are returned via "runtime_error" kv pair
# -------------------------------------------------------------------------- #
if len(ERROR_MESSAGE) !=0:
    output_structure = {
        "model_version": MODEL_VERSION,
        "runtime_error": ERROR_MESSAGE,
        "output_filename": JSON_OUTPUT_NAME,
        "parameters": [],
        "content": []
    }

    with open(outfile, 'w') as output_file:
        json.dump(output_structure, output_file, indent=3)
