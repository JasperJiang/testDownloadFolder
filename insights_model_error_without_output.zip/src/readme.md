# src Directory
This directory contains the main API script for the model